# AdaptiveRobot - FRC architecture
# Copyright (c) 2026 Jacob Taylor (igowu) <https://github.com/igowuu>
# Code from: <https://github.com/igowuu/AdaptiveRobot.git>

# Licensed under the MIT License.
# See https://opensource.org/licenses/MIT for details.

from typing import final

from wpilib import TimedRobot

from adaptive_robot.telemetry.telemetry import TelemetryPublisher
from adaptive_robot.telemetry.struct_telemetry import TelemetryStructPublisher
from adaptive_robot.adaptive_component import AdaptiveComponent
from adaptive_robot.autonomous.routines import Action


class AdaptiveRobot(TimedRobot):
    """
    Wrapper for TimedRobot that allows for a dynamic structure while enforcing safety measures 
    and quality-of-life improvements.
    """
    def __init__(self) -> None:
        super().__init__()

        self.telemetry_publisher = TelemetryPublisher()
        self.telemetry_struct_publisher = TelemetryStructPublisher()

        self.components: list[AdaptiveComponent] = []
        self.actions: list[Action] = []

    @final
    def add_component(self, component: "AdaptiveComponent") -> None:
        """
        Adds a component to the scheduler.
        """
        self.components.append(component)

    def _update_components_post_loop(self) -> None:
        for component in self.components:
            component.update_tunable_constants()
            component.update_tunable_pids()

    @final
    def robotInit(self) -> None:
        self.onRobotInit()

    @final
    def robotPeriodic(self) -> None:
        for component in self.components:
            try:
                component.record_safety_telemetry()
                component.publish_telemetry()

                if not self.isEnabled():
                    continue

                if component.is_healthy():
                    component.execute()
                    component.reset_failure_count()
                else:
                    component.on_faulted()

            except Exception as e:
                component.record_failure(e)

        self._update_components_post_loop()

        self.onRobotPeriodic()

    @final
    def disabledInit(self) -> None:
        self.onDisabledInit()

    @final
    def disabledPeriodic(self) -> None:
        self.onDisabledPeriodic()

    @final
    def disabledExit(self) -> None:
        self.onDisabledExit()

    @final
    def teleopInit(self) -> None:
        self.onTeleopInit()

    @final
    def teleopPeriodic(self) -> None:
        self.onTeleopPeriodic()

    @final
    def teleopExit(self) -> None:
        self.onTeleopExit()

    @final
    def autonomousInit(self) -> None:
        self.onAutonomousInit()

    @final
    def autonomousPeriodic(self) -> None:
        self.onAutonomousPeriodic()

    @final
    def autonomousExit(self) -> None:
        self.onAutonomousExit()
    
    @final
    def testInit(self) -> None:
        self.onTestInit()

    @final
    def testPeriodic(self) -> None:
        self.onTestPeriodic()

    @final
    def testExit(self) -> None:
        self.onTestExit()

    def onRobotInit(self) -> None:
        """
        Robot-wide initialization code should go here.

        Users should override this method for default Robot-wide initialization which will be called 
        when the robot is first powered on. 
        It will be called exactly one time.
        """
        pass

    def onRobotPeriodic(self) -> None:
        """
        Periodic code for all modes should go here.

        This function is called each time a new packet is received from the driver station.
        """
        pass
    
    def onDisabledInit(self) -> None:
        """
        Initialization code for disabled mode should go here.

        Users should override this method for initialization code 
        which will be called each time the robot enters disabled mode.
        """
        pass

    def onDisabledPeriodic(self) -> None:
        """
        Periodic code for disabled mode should go here.

        Users should override this method for code which will be called each time a new packet 
        is received from the driver station and the robot is in disabled mode.
        """
        pass

    def onDisabledExit(self) -> None:
        """
        Exit code for disabled mode should go here.

        Users should override this method for code 
        which will be called each time the robot exits disabled mode.
        """
        pass
    
    def onTeleopInit(self) -> None:
        """
        Initialization code for teleop mode should go here.

        Users should override this method for initialization code 
        which will be called each time the robot enters teleop mode.
        """
        pass

    def onTeleopPeriodic(self) -> None:
        """
        Periodic code for teleop mode should go here.

        Users should override this method for code which will be called each time a new packet 
        is received from the driver station and the robot is in teleop mode.
        """
        pass

    def onTeleopExit(self) -> None:
        """
        Exit code for teleop mode should go here.

        Users should override this method for code 
        which will be called each time the robot exits teleop mode.
        """
        pass

    def onAutonomousInit(self) -> None:
        """
        Initialization code for autonomous mode should go here.

        Users should override this method for initialization code 
        which will be called each time the robot enters autonomous mode.
        """
        pass

    def onAutonomousPeriodic(self) -> None:
        """
        Periodic code for autonomous mode should go here.

        Users should override this method for code which will be called each time a new packet 
        is received from the driver station and the robot is in autonomous mode."""
        pass
    
    def onAutonomousExit(self) -> None:
        """
        Exit code for autonomous mode should go here.

        Users should override this method for code 
        which will be called each time the robot exits autonomous mode.
        """
        pass

    def onTestInit(self) -> None:
        """
        Initialization code for test mode should go here.

        Users should override this method for initialization code 
        which will be called each time the robot enters test mode.
        """
        pass

    def onTestPeriodic(self) -> None:
        """
        Periodic code for test mode should go here.

        Users should override this method for code which will be called each time a new packet 
        is received from the driver station and the robot is in test mode.
        """
        pass

    def onTestExit(self) -> None:
        """
        Exit code for test mode should go here.

        Users should override this method for code 
        which will be called each time the robot exits test mode.
        """
        pass
