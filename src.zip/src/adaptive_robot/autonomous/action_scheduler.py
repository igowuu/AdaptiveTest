import wpilib

from adaptive_robot.autonomous.routines import Action, ActionState


class ActionScheduler:
    """
    Executes and manages the lifecycle of scheduled actions.
    """
    def __init__(self) -> None:
        self._actions: list[Action] = []

    def schedule(self, action: Action) -> None:
        """
        Adds an action to be executed by the scheduler.
        """
        if action in self._actions:
            return

        if action.state != ActionState.READY:
            raise RuntimeError("Attempted to schedule an action that was not ready.")

        self._actions.append(action)

    def run(self) -> None:
        """
        Runs one scheduler iteration over all scheduled actions.
        """
        for action in list(self._actions):
            try:
                if action.state == ActionState.READY:
                    action.start()

                if action.state == ActionState.RUNNING:
                    action.update()

                if action.is_finished:
                    self._actions.remove(action)

            except Exception as exception:
                wpilib.reportError(f"Action scheduler caught exception: {exception}")

                if action.state == ActionState.RUNNING:
                    try:
                        action.cancel()
                    except Exception as cancel_exception:
                        wpilib.reportError(f"Action scheduler failed to cancel action: {cancel_exception}")

                if action in self._actions:
                    self._actions.remove(action)

    def cancel(self, action: Action) -> None:
        """
        Cancels a specific scheduled action.
        """
        if action not in self._actions:
            return

        if action.state == ActionState.RUNNING:
            action.cancel()

        self._actions.remove(action)

    def cancel_all(self) -> None:
        """
        Cancels and clears all scheduled actions.
        """
        for action in list(self._actions):
            if action.state == ActionState.RUNNING:
                action.cancel()

            self._actions.remove(action)

    def has_scheduled_actions(self) -> bool:
        """
        Returns True if any actions are currently scheduled.
        """
        return len(self._actions) > 0
