from adaptive_robot.autonomous import Action


class TestAction(Action):
    def __init__(self) -> None:
        super().__init__()
        self.iterations = 5

    def on_start(self) -> bool:
        """
        Method called once at the start of an Action.
        Returns True if the Action should immediately abort.
        """
        print("Started action!")
        return False
    
    def on_update(self) -> bool:
        """
        Method called each iteration.
        Returns True if the action should finish.
        """
        print(f"Iteration number: {self.iterations}")
        if self.iterations >= 5:
            return True
        else:
            self.iterations += 1
            return False
    
    def on_finish(self) -> None:
        print("Finished!")
    
    def on_cancel(self) -> None:
        print("Cancelled!")


class TestActionTwo(Action):
    def __init__(self) -> None:
        super().__init__()
        self.iterations = 5

    def on_start(self) -> bool:
        """
        Method called once at the start of an Action.
        Returns True if the Action should immediately abort.
        """
        print("Started actionTwo!")
        return False
    
    def on_update(self) -> bool:
        """
        Method called each iteration.
        Returns True if the action should finish.
        """
        print(f"Iteration number for two: {self.iterations}")
        if self.iterations >= 5:
            return True
        else:
            self.iterations += 1
            return False
    
    def on_finish(self) -> None:
        print("Finished ActionTwo!")
    
    def on_cancel(self) -> None:
        print("Cancelled ActionTwo!")
