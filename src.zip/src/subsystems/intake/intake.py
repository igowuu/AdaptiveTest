from adaptive_robot import AdaptiveRobot
from adaptive_robot import AdaptiveComponent


class Intake(AdaptiveComponent):
    def __init__(self, robot: AdaptiveRobot) -> None:
        super().__init__(robot, "Intake")

