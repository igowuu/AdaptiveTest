from abc import ABC, abstractmethod

from adaptive_robot.autonomous.steps import Step


class RoutineBase(Step, ABC):
    """
    Contains the required methods for both types of routines.
    """
    @abstractmethod
    def __init__(self, steps: list[Step]) -> None:
        """
        Initializes a routine given a list of steps.
        """
        ...

    @abstractmethod
    def start(self) -> None:
        """
        Starts and initializes the routine.
        """
        ...
    
    @abstractmethod
    def update(self) -> None:
        """
        Updates the routine each iteration.
        """
        ...

    @abstractmethod
    def end(self) -> None:
        """
        Ends the routine once finished.
        """
        ...

    @property
    @abstractmethod
    def is_finished(self) -> bool:
        """
        Returns True if the routine is finished.
        """
        ...


class SequentialRoutine(RoutineBase):
    """
    Initializes a sequential routine, where each step waits for the previous to end before executing.
    """
    def __init__(self, steps: list[Step]) -> None:
        """
        Given a list of steps, initializes a sequential routine.
        Each step will be executed in ascending order in the list.
        """
        self.steps = steps
        self.current_index = 0

    def start(self) -> None:
        """
        Starts the first step."""
        self.current_index = 0
        if self.steps:
            self.steps[0].start()

    def update(self) -> None:
        """
        Updates the routine each iteration if not all steps have been completed.
        If the currently running step has ended, progresses to the next step.
        """
        if self.current_index >= len(self.steps):
            return

        current_step = self.steps[self.current_index]
        current_step.update()

        if current_step.is_finished:
            current_step.end()
            self.current_index += 1
            if self.current_index < len(self.steps):
                self.steps[self.current_index].start()

    def end(self) -> None:
        """
        Stops the current step if still running.
        """
        if self.current_index < len(self.steps):
            self.steps[self.current_index].end()

    @property
    def is_finished(self) -> bool:
        """
        Returns True if all steps have been completed.
        """
        return self.current_index >= len(self.steps)


class ParallelRoutine(RoutineBase):
    """
    Initializes a parallel routine, where each step runs at the same time.
    The routine will end once all steps have finished.
    """
    def __init__(self, steps: list[Step]) -> None:
        """
        Given a list of steps, initializes a parallel routine.
        """
        self.steps = steps
        self.active_steps: list[Step] = []

    def start(self) -> None:
        """
        Calls the start method for all steps.
        """
        self.active_steps = self.steps
        for step in self.active_steps:
            step.start()

    def update(self) -> None:
        """
        Updates all steps that haven't finished.
        """
        still_active: list[Step] = []

        for step in self.active_steps:
            step.update()
            if step.is_finished:
                step.end()
            else:
                still_active.append(step)

        self.active_steps = still_active

    def end(self) -> None:
        """
        Stops all running steps.
        """
        for step in self.active_steps:
            step.end()
        self.active_steps.clear()

    @property
    def is_finished(self) -> bool:
        """
        Returns True if there are no more active steps.
        """
        return len(self.active_steps) == 0
