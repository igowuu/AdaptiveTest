from abc import ABC, abstractmethod


class Step(ABC):
    @abstractmethod
    def start(self) -> None:
        """
        Starts and initializes a step.
        """
        pass

    @abstractmethod
    def update(self) -> None:
        """
        Updates the step.
        """
        pass

    @abstractmethod
    def end(self) -> None:
        """
        Ends the routine once finished.
        """
        pass

    @property
    @abstractmethod
    def is_finished(self) -> bool:
        """
        Returns True if step is complete.
        """
        pass
